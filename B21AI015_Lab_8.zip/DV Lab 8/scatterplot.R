library(shiny)
library(ggplot2)
library(plotly)
library(dplyr)

custom_data <- read.csv("new-thyroid.data")  

ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      body {
        background-color: #f4f4f4;
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
      }
      .sidebar {
        background-color: #ffffff;
        border-right: 1px solid #dddddd;
        padding: 20px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        z-index: 999;
        overflow-y: auto;
        width: 250px;
      }
      .main {
        padding: 20px;
        margin-left: 250px;
        position: relative;
      }
      h1 {
        color: #333333;
        margin-bottom: 20px;
      }
      label {
        color: #555555;
      }
      .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        color: #ffffff;
      }
      .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
        color: #ffffff;
      }
    "))
  ),
  sidebarLayout(
    sidebarPanel(
      h1("Custom Scatter Plot", style = "font-weight: bold;"),
      selectInput(inputId = "xvar", label = "X-axis Variable", 
                  choices = colnames(custom_data)[-1], selected = colnames(custom_data)[1]),
      selectInput(inputId = "yvar", label = "Y-axis Variable", 
                  choices = colnames(custom_data)[-1], selected = colnames(custom_data)[2]),
      checkboxGroupInput(inputId = "species", label = "Select Classes",
                         choices = unique(custom_data$Class), selected = unique(custom_data$Class)),
      sliderInput(inputId = "size", label = "Point Size",
                  min = 1, max = 10, value = 3),
      selectInput(inputId = "shape", label = "Point Shape",
                  choices = c("Circle" = 16, "Square" = 15, "Triangle" = 17), selected = 16),
      uiOutput("color_ui"),
      actionButton("reset_btn", "Reset", class = "btn-primary")
    ),
    mainPanel(
      plotlyOutput(outputId = "scatterplot", height = "600px"),
      style = "background-color: #ffffff;"
    )
  )
)

server <- function(input, output, session) {
  
  output$color_ui <- renderUI({
    species_colors <- lapply(unique(custom_data$Class), function(s) {
      tagList(
        tags$label(paste0("Color for ", s)),
        selectInput(inputId = paste0(s, "_color"), "", 
                    choices = c("Red", "Green", "Blue", "Yellow", "Purple"), 
                    selected = "Red")
      )
    })
    do.call(tagList, species_colors)
  })
  
  observeEvent(input$reset_btn, {
    updateSelectInput(session, "xvar", selected = colnames(custom_data)[1])
    updateSelectInput(session, "yvar", selected = colnames(custom_data)[2])
    updateCheckboxGroupInput(session, "species", selected = unique(custom_data$Class))
    updateSliderInput(session, "size", value = 3)
    updateSelectInput(session, "shape", selected = 16)
    updateSelectInput(session, "Red_color", selected = "Red")
    updateSelectInput(session, "Green_color", selected = "Green")
    updateSelectInput(session, "Blue_color", selected = "Blue")
    updateSelectInput(session, "Yellow_color", selected = "Yellow")
    updateSelectInput(session, "Purple_color", selected = "Purple")
  })
  
  observe({
    filtered_data <- custom_data %>% 
      filter(Class %in% input$species)
    
    species_colors <- lapply(unique(filtered_data$Class), function(s) {
      if(!is.null(input[[paste0(s, "_color")]])){
        tolower(input[[paste0(s, "_color")]])
      } else {
        "black" 
      }
    })
    names(species_colors) <- unique(filtered_data$Class)
    
    filtered_data$Class <- as.factor(filtered_data$Class)
    
    p <- ggplot(data = filtered_data, aes_string(x = input$xvar, y = input$yvar, 
                                                 color = "Class")) +
      geom_point(shape = input$shape, size = input$size) +
      scale_color_manual(values = species_colors) + 
      scale_size_continuous(range = c(1, 10)) 
    
    output$scatterplot <- renderPlotly({
      ggplotly(p) %>% 
        layout(dragmode = "pan", hovermode = "closest") %>% 
        config(displayModeBar = TRUE)
    })
  })
}

shinyApp(ui = ui, server = server)
