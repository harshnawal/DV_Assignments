library(shiny)
library(plotly)
library(readr)

ui <- fluidPage(
  titlePanel("Histogram"),
  
  fluidRow(
    column(width = 3,
           selectInput("column",
                       label = "Select a column:",
                       choices = NULL),
           sliderInput(inputId = "bins",
                       label = "Number of bins:",
                       min = 1,
                       max = 50,
                       value = 30),
           selectInput("hist_color",
                       label = "Histogram Color:",
                       choices = c("Blue" = "#1F77B4", "Red" = "#FF5733", "Green" = "#4CAF50", "Purple" = "#800080"),
                       selected = "#1F77B4")
    ),
    column(width = 9,
           plotlyOutput(outputId = "plot")
    )
  )
)

server <- function(input, output, session) {
  
  df <- reactive({
    read.csv("new-thyroid.data", header = TRUE)
  })
  
  observe({
    if (!is.null(df())) {
      updateSelectInput(session, "column", choices = names(df()))
    }
  })
  
  output$plot <- renderPlotly({
    req(input$column)
    
    if (!is.null(df())) {
      selected_column <- df()[[input$column]]
      
      if (is.numeric(selected_column)) {
        p <- plot_ly() %>%
          add_histogram(x = ~selected_column, nbinsx = input$bins, marker = list(color = input$hist_color)) %>%
          layout(xaxis = list(title = input$column), yaxis = list(title = "Frequency"),
                 title = paste("Histogram for", input$column))
        
        return(p)
      }
    }
  })
}

shinyApp(ui = ui, server = server)
