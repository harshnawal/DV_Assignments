library(shiny)
library(ggplot2)
library(plotly)

data <- read.csv("new-thyroid.data", header = FALSE)
colnames(data) <- c("Class", "T3_resin", "Total_Serum_thyroxin", 
                    "Total_serum_triiodothyronine", "Basal_TSH", 
                    "Max_TSH_diff")

ui <- fluidPage(
  titlePanel("Thyroid Dataset Visualization"),
  sidebarLayout(
    sidebarPanel(
      h3("Select Attribute"),
      selectInput("attribute", "Attribute:",
                  choices = c("T3_resin", "Total_Serum_thyroxin", 
                              "Total_serum_triiodothyronine", "Basal_TSH", 
                              "Max_TSH_diff"),
                  selected = "T3_resin")
    ),
    mainPanel(
      plotlyOutput("violin_plot")
    )
  )
)

server <- function(input, output) {
  output$violin_plot <- renderPlotly({
    plot_ly(data, x = ~as.factor(Class), y = ~get(input$attribute), type = "violin", box = list(visible = TRUE), meanline = list(visible = TRUE)) %>%
      layout(title = paste("Box Plot for", input$attribute),
             height = 700)  # Adjust the height and width as needed
  })
}

shinyApp(ui = ui, server = server)
